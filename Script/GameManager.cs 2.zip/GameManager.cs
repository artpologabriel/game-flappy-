﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{

    public Texture[] CardTexture;
    public Sprite[] CardSprite;

    public Image player1card1Image;
    public Image player1card2Image;
    public Image player2card1Image;
    public Image player2card2Image;

    public Image publiccard1Image;
    public Image publiccard2Image;
    public Image publiccard3Image;
    public Image publiccard4Image;
    public Image publiccard5Image;

    public List<Card> card = new List<Card>();
    public List<CardsValue> cardValue = new List<CardsValue>(); 

    public List<Card> player1card = new List<Card>(); 
    public List<Card> player2card = new List<Card>(); 
    public List<Card> publiccard = new List<Card>(); 
    
    public Text ButtonText;
    

    public int cardCount ;

    // Start is called before the first frame update
    void Start()
    {
        int num = 0;

        string type = "Clubs";

        for( int i = 0; i < 12 ; i++){


            
        }

        card.Add(new Card("2 of "+type, 2 , 2, CardSprite[num++]));
        card.Add(new Card("3 of "+type, 3 , 3, CardSprite[num++]));
        card.Add(new Card("4 of "+type, 4 , 4, CardSprite[num++]));
        card.Add(new Card("5 of "+type, 5 , 5, CardSprite[num++]));
        card.Add(new Card("6 of "+type, 6 , 6, CardSprite[num++]));
        card.Add(new Card("7 of "+type, 7 , 7, CardSprite[num++]));
        card.Add(new Card("8 of "+type, 8 , 8, CardSprite[num++]));
        card.Add(new Card("9 of "+type, 9 , 9, CardSprite[num++])); 
        card.Add(new Card("10 of "+type, 10 , 10, CardSprite[num++]));
        card.Add(new Card("Jack of "+type, 11 , 11, CardSprite[num++]));
        card.Add(new Card("Queen of "+type, 12 , 12, CardSprite[num++]));
        card.Add(new Card("King of "+type, 13 , 13, CardSprite[num++]));               
        card.Add(new Card("Ace of "+type, 14 , 1, CardSprite[num++]));
        
        type = "Dianmonds";
        card.Add(new Card("2 of "+type, 2 , 2, CardSprite[num++]));
        card.Add(new Card("3 of "+type, 3 , 3, CardSprite[num++]));
        card.Add(new Card("4 of "+type, 4 , 4, CardSprite[num++]));
        card.Add(new Card("5 of "+type, 5 , 5, CardSprite[num++]));
        card.Add(new Card("6 of "+type, 6 , 6, CardSprite[num++]));
        card.Add(new Card("7 of "+type, 7 , 7, CardSprite[num++]));
        card.Add(new Card("8 of "+type, 8 , 8, CardSprite[num++]));
        card.Add(new Card("9 of "+type, 9 , 9, CardSprite[num++])); 
        card.Add(new Card("10 of "+type, 10 , 10, CardSprite[num++]));
        card.Add(new Card("Jack of "+type, 11 , 11, CardSprite[num++]));
        card.Add(new Card("Queen of "+type, 12 , 12, CardSprite[num++]));
        card.Add(new Card("King of "+type, 13 , 13, CardSprite[num++]));               
        card.Add(new Card("Ace of "+type, 14 , 1, CardSprite[num++]));

        type = "Hearts";
         card.Add(new Card("2 of "+type, 2 , 2, CardSprite[num++]));
        card.Add(new Card("3 of "+type, 3 , 3, CardSprite[num++]));
        card.Add(new Card("4 of "+type, 4 , 4, CardSprite[num++]));
        card.Add(new Card("5 of "+type, 5 , 5, CardSprite[num++]));
        card.Add(new Card("6 of "+type, 6 , 6, CardSprite[num++]));
        card.Add(new Card("7 of "+type, 7 , 7, CardSprite[num++]));
        card.Add(new Card("8 of "+type, 8 , 8, CardSprite[num++]));
        card.Add(new Card("9 of "+type, 9 , 9, CardSprite[num++])); 
        card.Add(new Card("10 of "+type, 10 , 10, CardSprite[num++]));
        card.Add(new Card("Jack of "+type, 11 , 11, CardSprite[num++]));
        card.Add(new Card("Queen of "+type, 12 , 12, CardSprite[num++]));
        card.Add(new Card("King of "+type, 13 , 13, CardSprite[num++]));               
        card.Add(new Card("Ace of "+type, 14 , 1, CardSprite[num++]));

        type = "Spades";
        card.Add(new Card("2 of "+type, 2 , 2, CardSprite[num++]));
        card.Add(new Card("3 of "+type, 3 , 3, CardSprite[num++]));
        card.Add(new Card("4 of "+type, 4 , 4, CardSprite[num++]));
        card.Add(new Card("5 of "+type, 5 , 5, CardSprite[num++]));
        card.Add(new Card("6 of "+type, 6 , 6, CardSprite[num++]));
        card.Add(new Card("7 of "+type, 7 , 7, CardSprite[num++]));
        card.Add(new Card("8 of "+type, 8 , 8, CardSprite[num++]));
        card.Add(new Card("9 of "+type, 9 , 9, CardSprite[num++])); 
        card.Add(new Card("10 of "+type, 10 , 10, CardSprite[num++]));
        card.Add(new Card("Jack of "+type, 11 , 11, CardSprite[num++]));
        card.Add(new Card("Queen of "+type, 12 , 12, CardSprite[num++]));
        card.Add(new Card("King of "+type, 13 , 13, CardSprite[num++]));               
        card.Add(new Card("Ace of "+type, 14 , 1, CardSprite[num++]));
    

        card.Sort();
        
        
        foreach (Card cardResult in card)
        {
           // Debug.Log( cardResult.name + cardResult.value1 + cardResult.value2);
            cardCount++;
        }

        StartCoroutine(SetCard(card));
    }

    public IEnumerator SetCard(List<Card> card){
        
        //Debug.Log("SetCard Function");
        float timer = 0.1f;
        SetPlayerCard(card , player1card, player1card1Image);
        yield return new WaitForSeconds(timer);
        SetPlayerCard(card , player1card, player1card2Image);
        yield return new WaitForSeconds(timer);
        SetPlayerCard(card , player2card, player2card1Image);
        yield return new WaitForSeconds(timer);
        SetPlayerCard(card , player2card, player2card2Image);
        yield return new WaitForSeconds(timer);
        SetPlayerCard(card , publiccard, publiccard1Image);
        yield return new WaitForSeconds(timer);
        SetPlayerCard(card , publiccard, publiccard2Image);
        yield return new WaitForSeconds(timer);
        SetPlayerCard(card , publiccard, publiccard3Image);
        yield return new WaitForSeconds(timer);
        SetPlayerCard(card , publiccard, publiccard4Image);
        yield return new WaitForSeconds(timer);
        SetPlayerCard(card , publiccard, publiccard5Image);
        yield return new WaitForSeconds(timer);

        CheckCards();        
    }


    void SetPlayerCard(List<Card> card, List<Card> playercard, Image cardImage){
       int i = Random.Range(0,cardCount);
       //Debug.Log(cardCount);
       // Debug.Log(card[i].name + card[i].value1);  
        playercard.Add(new Card(card[i].name ,card[i].value1  , card[i].value2, card[i].sprite ));
        cardImage.GetComponent<Image>().sprite = card[i].sprite;
       // string cardSpriteName = CardSprite[i].ToString();
        card.Remove(card[i]);
        cardCount = cardCount - 1;
        //Debug.Log("cardCount:"+cardCount);
        
    }

    void CheckCards(){

        for (int i = 0; i < 5; i++)
        {
            player1card.Add(new Card(publiccard[i].name, publiccard[i].value1, publiccard[i].value2, publiccard[i].sprite));
            player2card.Add(new Card(publiccard[i].name, publiccard[i].value1, publiccard[i].value2, publiccard[i].sprite));
        }


        Debug.Log("cardCount:"+cardCount);

         foreach (Card playercards in player1card)
        {
          //Debug.Log("Player1Cards:" + playercards.name );
        }

        foreach (Card playercards in player2card)
        {
          //Debug.Log("Player2Cards:" + playercards.name );
        }
    

        CompareCards(player1card, player2card);
    }





    void CompareCards(List<Card> playercard1, List<Card> playercard2){

        
        if(EvaluateCard(playercard1) == EvaluateCard(playercard2)){            
          Debug.Log("Draw");   
        }
        
        if(EvaluateCard(playercard1) > EvaluateCard(playercard1)){            
          Debug.Log("Player 1 Win");   
        }

        if(EvaluateCard(playercard1) < EvaluateCard(playercard1)){            
          Debug.Log("Player 2 Win");   
        }


        Debug.Log(EvaluateCard(playercard1) + " : " + EvaluateCard(playercard2));
    }


    public int EvaluateCard(List<Card> pc){


        foreach(Card p in pc){
           // Debug.Log(p.value1);

            if(p.value1 == 14){
                //Debug.Log("Theres an ace");
            }
        }


        int matches = 0;

        if(pc[0].value1 == pc[1].value1){
        matches++;
        //Debug.Log("Card on hand matches");        
        }

        for (int i = 2 ; i < 7 ; i++)
        {
            if(pc[0].value1 == pc[i].value1){                    
                    matches++;
                   // Debug.Log("match! " + matches);
                   // pc.Remove(pc[i]);                    
            }

            if(pc[1].value1 == pc[i].value1){                    
                    matches++;
                  //  Debug.Log("match! " + matches);
                  //  pc.Remove(pc[i]);
            }
        }


        if (matches == 1){
            //Debug.Log("One pair");            
        }else if(matches == 2){
            //Debug.Log("Two pair");            
        } else if(matches == 3){
            //Debug.Log("Three of a kind");            
        } else {


        }

        return matches;
    }




    public void PlayAgain(){

            player1card.Clear();
            player2card.Clear();
            publiccard.Clear();

            if(cardCount < 20){
            
            ButtonText.text = "Play Last Set";

            }


        if(cardCount < 9){            
            
            
            SceneManager.LoadScene("Poker");
            
        } else
        {
             StartCoroutine(SetCard(card));
        }

    }


}
