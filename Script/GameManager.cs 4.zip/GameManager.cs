﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{

    public Texture[] CardTexture;
    public Sprite[] CardSprite;

    public Text player1Hand;
    public Text player2Hand;
    public Text gameResult;

    public int MatchCardValueAndWho1;
    public int MatchCardValueAndWho2;

    public Text MatchValueWho1;
    public Text MatchValueWho2;

    public Image player1card1Image;
    public Image player1card2Image;
    public Image player2card1Image;
    public Image player2card2Image;

    public Image publiccard1Image;
    public Image publiccard2Image;
    public Image publiccard3Image;
    public Image publiccard4Image;
    public Image publiccard5Image;

    public List<Card> card = new List<Card>();
    public List<CardsValue> cardValue = new List<CardsValue>();
 

    public List<Card> player1card = new List<Card>(); 
    public List<Card> player2card = new List<Card>(); 
    public List<Card> publiccard = new List<Card>(); 

    public List<Card> player1publiccard = new List<Card>();
    public List<Card> player2publiccard = new List<Card>(); 
    

    private List<Card> playerClubs = new List<Card>(); 
    private List<Card> playerDiamonds = new List<Card>();
    private List<Card> playerHearts = new List<Card>();
    private List<Card> playerSpades = new List<Card>();
    
    public Text ButtonText;
    

    public int cardCount ;

    // Start is called before the first frame update
    void Start()
    {
        int num = 0;
        int cardNumber = 2; 
        for( int i = 0; i < 13 ; i++){
                card.Add(new Card("Clubs", cardNumber , cardNumber++, CardSprite[num++]));
        }
        cardNumber = 2; 
        for( int i = 0; i < 13 ; i++){
                card.Add(new Card("Diamonds", cardNumber , cardNumber++, CardSprite[num++]));
        }
        cardNumber = 2; 
        for( int i = 0; i < 13 ; i++){
                card.Add(new Card("Hearts", cardNumber , cardNumber++, CardSprite[num++]));
        }
        cardNumber = 2; 
        for( int i = 0; i < 13 ; i++){
                card.Add(new Card("Spades", cardNumber , cardNumber++, CardSprite[num++]));
        }


        card.Sort();
        
        
        foreach (Card cardResult in card)
        {
         //  Debug.Log( cardResult.name + " : "+ cardResult.value1 + " : "+ cardResult.sprite.ToString());
            cardCount++;
        }

        StartCoroutine(SetCard(card));
    }

    public IEnumerator SetCard(List<Card> card){
        
        //Debug.Log("SetCard Function");
        float timer = 0.1f;
        SetPlayerCard(card , player1card, player1card1Image);
        yield return new WaitForSeconds(timer);
        SetPlayerCard(card , player1card, player1card2Image);
        yield return new WaitForSeconds(timer);
        SetPlayerCard(card , player2card, player2card1Image);
        yield return new WaitForSeconds(timer);
        SetPlayerCard(card , player2card, player2card2Image);
        yield return new WaitForSeconds(timer);
        SetPlayerCard(card , publiccard, publiccard1Image);
        yield return new WaitForSeconds(timer);
        SetPlayerCard(card , publiccard, publiccard2Image);
        yield return new WaitForSeconds(timer);
        SetPlayerCard(card , publiccard, publiccard3Image);
        yield return new WaitForSeconds(timer);
        SetPlayerCard(card , publiccard, publiccard4Image);
        yield return new WaitForSeconds(timer);
        SetPlayerCard(card , publiccard, publiccard5Image);
        yield return new WaitForSeconds(timer);

        CheckCards();        
    }


    void SetPlayerCard(List<Card> card, List<Card> playercard, Image cardImage){
       
       
       int i = Random.Range(0,cardCount);
       //int i = 0;
       
       //Debug.Log(cardCount);
       // Debug.Log(card[i].name + card[i].value1);  
        playercard.Add(new Card(card[i].name ,card[i].value1  , card[i].value2, card[i].sprite ));
        cardImage.GetComponent<Image>().sprite = card[i].sprite;
       // string cardSpriteName = CardSprite[i].ToString();
        card.Remove(card[i]); // remove or take the card from the deck 
        cardCount = cardCount - 1;
        //Debug.Log("cardCount:"+cardCount);
        
    }

    void CheckCards(){

        for (int i = 0; i < 2; i++)
        {
            player1publiccard.Add(new Card(player1card[i].name, player1card[i].value1, player1card[i].value2, player1card[i].sprite));
            player2publiccard.Add(new Card(player2card[i].name, player2card[i].value1, player2card[i].value2, player2card[i].sprite));
        }


        for (int i = 0; i < 5; i++)
        {
            player1publiccard.Add(new Card(publiccard[i].name, publiccard[i].value1, publiccard[i].value2, publiccard[i].sprite));
            player2publiccard.Add(new Card(publiccard[i].name, publiccard[i].value1, publiccard[i].value2, publiccard[i].sprite));
        }


            
        

       // Debug.Log("cardCount:"+cardCount);
        
       // player1publiccard.Sort();

         foreach (Card playercards in player1publiccard)
        {
         //Debug.Log("Player1Cards:" + playercards.value1 + playercards.name );
        }

        foreach (Card playercards in player2publiccard)
        {
        // Debug.Log("Player2Cards:" + playercards.value1 + playercards.name );
        }

        /*
        foreach(Card p in removeLastExcessCard(player1publiccard)){
            Debug.Log("AfterRemovePlayer1Cards:" + p.value1 + p.name );
        }
        */


        CompareCards(player1publiccard, player2publiccard);
    }





    void CompareCards(List<Card> player1publiccard, List<Card> player2publiccard){
    


        if(EvaluateCard(player1publiccard, player1card, "player1") == EvaluateCard(player2publiccard, player2card, "player2")){            
          

            if(MatchCardValueAndWho1 > MatchCardValueAndWho2){
                    Debug.Log("Player1 Wins");
                gameResult.text = "Player 1 Wins";

            } else if(MatchCardValueAndWho1 < MatchCardValueAndWho2){
                    Debug.Log("Player2 Wins");
                gameResult.text = "Player 2 Wins";
            } else

            /*
          if(HighCard(player1card,"player1") > HighCard(player2card,"player2")){
                Debug.Log("Player1 Wins");
                gameResult.text = "Player 1 Wins";
          }else if(HighCard(player1card,"player1") < HighCard(player2card,"player2")){  
                Debug.Log("Player2 Wins");
                gameResult.text = "Player 2 Wins";
          } else if(LowCard(player1card,"player1") > LowCard(player2card,"player2")){
                Debug.Log("Player1 Wins");
                gameResult.text = "Player 1 Wins";
          }else if(LowCard(player1card,"player1") < LowCard(player2card,"player2")){
                Debug.Log("Player2 Wins");
                gameResult.text = "Player 2 Wins";
          }else 
          */
          {
                Debug.Log("Draw");
                gameResult.text = "Draw";
          }


          //Debug.Log(EvaluateCard(player1publiccard, playercard1, "player1") + " : " + EvaluateCard(player2publiccard, playercard2, "player2"));
          return;
        }else if(EvaluateCard(player1publiccard, player1card, "player1") > EvaluateCard(player2publiccard, player2card, "player2")){            
          Debug.Log("Player1 Wins");
          gameResult.text = "Player 1 Wins";
         // Debug.Log(EvaluateCard(player1publiccard, playercard1, "player1") + " : " + EvaluateCard(player2publiccard, playercard2, "player2"));
          return;
        } else if(EvaluateCard(player1publiccard, player1card, "player1") < EvaluateCard(player2publiccard, player2card, "player2")){            
          Debug.Log("Player2 Wins");
          gameResult.text = "Player 2 Wins";
         // Debug.Log(EvaluateCard(player1publiccard, playercard1, "player1") + " : " + EvaluateCard(player2publiccard, playercard2, "player2"));
          return;
        } else {
            Debug.Log("What???");  
          //  Debug.Log(EvaluateCard(player1publiccard, playercard1, "player1") + " : " + EvaluateCard(player2publiccard, playercard2, "player2"));
            return;
        }

        //Debug.Log(EvaluateCard(player1publiccard, player1card, "player1"));
        //Debug.Log(EvaluateCard(player2publiccard, player2card, "player2"));
        
        
    }

     public int EvaluateCard(List<Card> pc, List<Card> defaultCards, string playerWho){

                if(RoyalFlush(pc, defaultCards).Contains("RoyalFlush")){
                        Debug.Log("RoyalFlush :"+ playerWho);
                        setTextLabel("RoyalFlush :"+ playerWho);    
                        return 1000;                                             
                }else if(RoyalFlush(pc, defaultCards).Contains("RoyalFlusX")){
                        Debug.Log("RoyalFlusX :"+ playerWho);
                        setTextLabel(" :"+ playerWho);    
                        return 0;                                             
                }else if(StraightFlush(pc, defaultCards, playerWho).Contains("StraightFlush")){
                        Debug.Log("StraightFlush :"+ playerWho);
                        setTextLabel("StraightFlush :"+ playerWho);
                        return 900 ;                         
                }else if(StraightFlush(pc, defaultCards, playerWho).Contains("StraightFlusX")){
                        Debug.Log("StraightFlusX :"+ playerWho);
                        setTextLabel(" :"+ playerWho);
                        return 0;
                }else if(FourOfAKind(pc, defaultCards, playerWho).Contains("FourOfAKind")){
                        Debug.Log("FourOfAKind :"+ playerWho);
                        setTextLabel("FourOfAKind :"+ playerWho);
                        return 800;
                }else if(FourOfAKind(pc, defaultCards, playerWho).Contains("FourOfAKinX")){
                        Debug.Log("FourOfAKinX :"+ playerWho);
                        setTextLabel(":"+ playerWho);
                        return 0;

                }else if(Flush(pc, defaultCards, playerWho).Contains("Flush")){
                        Debug.Log("Flush :"+ playerWho);
                        setTextLabel("Flush :"+ playerWho);
                        return 700;                                                
                
                }else if(Flush(pc, defaultCards, playerWho).Contains("FlusX")){
                        Debug.Log("FlusX :"+ playerWho);
                        setTextLabel(" :"+ playerWho);
                        return 0;

                }else if(FullHouse(pc, defaultCards, playerWho).Contains("FullHouse")){
                        Debug.Log("FullHouse:"+ playerWho);
                        setTextLabel("FullHouse:"+ playerWho);
                        return 600;  
                
                }else if(FullHouse(pc, defaultCards, playerWho).Contains("FullHousX")){
                        Debug.Log("FullHousX:"+ playerWho);
                        setTextLabel(":"+ playerWho);
                        return 0;

                }else if(Straight(pc, defaultCards, playerWho).Contains("Straight")){
                        Debug.Log("Straight:"+ playerWho);
                        setTextLabel("Straight:"+ playerWho);
                        return 500 ; 

                }else if(Straight(pc, defaultCards, playerWho).Contains("StraighX")){
                        Debug.Log("StraighX:"+ playerWho);
                        setTextLabel(":"+ playerWho);
                        return 0;

                }else if(ThreeOfAKind(pc, defaultCards, playerWho).Contains("ThreeOfAKind")){
                        Debug.Log("ThreeOfAKind:"+ playerWho);
                        setTextLabel("ThreeOfAKind:"+ playerWho);
                        return 400;                                                
                
                }else if(ThreeOfAKind(pc, defaultCards, playerWho).Contains("ThreeOfAKinX")){
                        Debug.Log("ThreeOfAKinX:"+ playerWho);
                        setTextLabel(":"+ playerWho);
                        return 0;

                }else if(TwoPairs(pc, defaultCards, playerWho).Contains("TwoPairs")){
                        Debug.Log("TwoPairs:"+ playerWho);
                        setTextLabel("TwoPairs:"+ playerWho);
                        return 300 ;                                                
                
                }else if(OnePair(pc, defaultCards, playerWho).Contains("OnePair")){
                        Debug.Log("OnePair:"+ playerWho);
                        setTextLabel("OnePair:"+ playerWho);
                        return 200 ;                                                
                }
                 else {
                    Debug.Log("Draw :"+ playerWho );
                    MatchCardValueAndWho1 = 0;
                    MatchCardValueAndWho2 = 0;
                    //setTextLabel("Draw :"+ playerWho );
                    setTextLabel(" :"+ playerWho );
                    return 0;
                    //return HighCard(defaultCards, playerWho);
                }           
    }

    public void setTextLabel(string str){

        string[] t = str.ToString().Split(":"[0]);
        
        if(str.Contains("player1")){            
            player1Hand.text = t[0];
        }else{
            
            player2Hand.text = t[0];
        }        

    }


    private string RoyalFlush(List<Card> pc, List<Card> defaultCards){


      
      

        int isClubs = 0;
        int isDiamonds = 0;
        int isHearts = 0;
        int isSpades = 0;
        bool isAce = false;
        
        foreach(Card p in pc){
           // Debug.Log(p.value1);
            if(p.name == "Clubs"){
                isClubs++;
                playerClubs.Add(p);
            } else if(p.name == "Diamonds"){
                isDiamonds++;
                playerDiamonds.Add(p);
            }else if(p.name == "Hearts"){
                isHearts++;
                playerHearts.Add(p);
            }else if(p.name == "Spades"){
                isSpades++;
                playerSpades.Add(p);
            }else{

            }

            if(p.value1 == 14){
               // Debug.Log("Theres an ace");
                isAce = true;
            } 

        }

            if(!isAce){
                    return "Nope";
            }
            
        foreach (Card playercards in playerClubs)
        {
         //Debug.Log("Clubs:" + playercards.value1 + playercards.name );
        }

        foreach (Card playercards in playerDiamonds)
        {
        // Debug.Log("Diamonds:" + playercards.value1 + playercards.name );
        }    

        foreach (Card playercards in playerHearts)
        {
        // Debug.Log("Hearts:" + playercards.value1 + playercards.name );
        }
        foreach (Card playercards in playerSpades)
        {
         //Debug.Log("Spades:" + playercards.value1 + playercards.name );
        }

           // Debug.Log(pc[0].value1 + " : " + pc[1].value1);

            if(isClubs > 4){                   

                    return isRoyal(playerClubs,defaultCards);
            }else             

            if(isDiamonds > 4){                   
                    return isRoyal(playerDiamonds,defaultCards);
            }else

            if(isHearts > 4){                   
                   return isRoyal(playerHearts, defaultCards);
            }else 

            if(isSpades > 4){                   
                   return isRoyal(playerSpades,defaultCards);
            }else
            
            { 
                //Debug.Log("Suite less than 5");
            return "Nope"; } 

    }

    private string isRoyal(List<Card> pc, List<Card> defaultCards){

            bool ace = false;
            bool king = false;
            bool queen = false;
            bool jack = false;
            bool ten = false;

            foreach(Card p in pc){
                    if(p.value1 == 14){ ace =true; 
                    //Debug.Log("Theres an Ace"); 
                    }
            }
            foreach(Card p in pc){                    
                    if(p.value1 == 13){ king=true; 
                    //Debug.Log("Theres a King"); 
                    }
            }
            foreach(Card p in pc){
                    if(p.value1 == 12){ queen=true; 
                    //Debug.Log("Theres a Queen"); 
                    }
            }
            foreach(Card p in pc){
                    if(p.value1 == 11){ jack=true; 
                    //Debug.Log("Theres a Jack"); 
                    }
            }
            foreach(Card p in pc){
                    if(p.value1 == 10){ ten=true;  
                    //Debug.Log("Theres a 10"); 
                    }
            }

            bool userCard = false;
            if((defaultCards[0].value1 ==14) || (defaultCards[1].value1== 14)){
                    userCard = true;
            }else 
            if((defaultCards[0].value1 ==13) || (defaultCards[1].value1== 13)){
                    userCard = true;
            }else 
            if((defaultCards[0].value1 ==12) || (defaultCards[1].value1== 12)){
                    userCard = true;
            }else 
            if((defaultCards[0].value1 ==11) || (defaultCards[1].value1== 11)){
                    userCard = true;
            }else
            if((defaultCards[0].value1 ==10) || (defaultCards[1].value1== 10)){
                    userCard = true;
            }else  {
                    userCard = false;
            }



            if(ace && king && queen && jack && ten && userCard ){
                return "RoyalFlush";
            }else if(ace && king && queen && jack && ten && !userCard ){
                return "RoyalFlusX";
            }else{
                return "Nope";
            }    
    }



    private bool IsPlayerCardIncluded(List<Card> pc, List<Card> defaultCards){
        
        //Debug.Log("IsPlayerCardIncluded");

        int included = 0;
        bool card1 = false;
        bool card2 = false;
            foreach(Card p in pc){
                    if(p.value1 == defaultCards[0].value1){ card1 = true; }
                    if(p.value1 == defaultCards[1].value1){ card2 = true; }
            }

       // Debug.Log("IsPlayerCardIncluded result: " + card1 + card2);

        if(card1 || card2){ 
            //Debug.Log("Included"); 
         return true; } else { return false; }

    }


    private string StraightFlush(List<Card> pc, List<Card> defaultCards, string playerWho){

        int isClubs = 0;
        int isDiamonds = 0;
        int isHearts = 0;
        int isSpades = 0;    
        
        List<Card> ClubCards = new List<Card>();
        List<Card> DiamondCards = new List<Card>();
        List<Card> HeartsCards = new List<Card>();
        List<Card> SpadesCards = new List<Card>();

        foreach(Card p in pc){
           // Debug.Log(p.value1);
            if(p.name == "Clubs"){
                isClubs++;
                ClubCards.Add(p);
            } else if(p.name == "Diamonds"){
                isDiamonds++;
                DiamondCards.Add(p);
            }else if(p.name == "Hearts"){
                isHearts++;
                HeartsCards.Add(p);
            }else if(p.name == "Spades"){
                isSpades++;
                SpadesCards.Add(p);
            }else{

            }
        }
          
        if(isClubs > 4){
               
                return checkIfStraight(removeLastExcessCard(ClubCards), defaultCards,playerWho);
            }else 
            if(isDiamonds > 4 ){
               // Debug.Log("Suite > 4");
                return checkIfStraight(removeLastExcessCard(DiamondCards),defaultCards,playerWho);
            } else
            if(isHearts > 4 ){
               // Debug.Log("Suite > 4");
                return checkIfStraight(removeLastExcessCard(HeartsCards), defaultCards,playerWho);
            }else
            if(isSpades > 4){
               // Debug.Log("Suite > 4");
                return checkIfStraight(removeLastExcessCard(SpadesCards), defaultCards,playerWho);
            }else{
                return "Nope";
            }           
            return "Nope";
        
    }


    private List<Card> removeLastExcessCard(List<Card> c ){
        //remove excess lowest card if any
        int howManyCards = 0;
        foreach(Card p in c){
                howManyCards++;
        }

        c.Sort();

            if(howManyCards == 7){
                c.Remove(c[0]);
                c.Remove(c[0]);
            }else if(howManyCards == 6){
                c.Remove(c[0]);
            }else{

            }


        return c;                    
    }


    

    private string checkIfStraight(List<Card> straightCard, List<Card> defaultCards, string playerWho){

          //  Debug.Log("checkIfStraight");

        straightCard.Sort();

         if((straightCard[0].value1 + 1 == straightCard[1].value1) && (straightCard[1].value1 + 1 == straightCard[2].value1) 
        && (straightCard[2].value1 + 1 == straightCard[3].value1) && (straightCard[3].value1 + 1 == straightCard[4].value1)) {

                if(IsPlayerCardIncluded(straightCard,defaultCards)){                    
                    return "StraightFlush" ;
                } else { 
                    return "StraightFlusX" ;
                    }
        } else{
                return "Nope" ;
        }

    }

    private string FourOfAKind(List<Card> pc, List<Card> defaultCards, string playerWho){

    //Debug.Log("Checking if FourOfAKind");
    List<Card> straightCard = new List<Card>();
    List<Card> straightCard1 = new List<Card>();
    List<Card> straightCard2 = new List<Card>();
    List<Card> straightCard3 = new List<Card>(); 

        pc.Sort();
        
            for(int i = 0; i < 4; i++){
                straightCard.Add(pc[i]);
            }

            for(int i = 1; i < 5; i++){
                straightCard1.Add(pc[i]);
            }
        
            for(int i = 2; i < 6; i++){
                straightCard2.Add(pc[i]);
            }
            for(int i = 3; i < 7; i++){
                straightCard3.Add(pc[i]);
            }

            

            if(FourPair(straightCard3, defaultCards)){
                if(IsPlayerCardIncluded(straightCard3,defaultCards)){
                       return "FourOfAKind"; 
                }else{
                    return "FourOfAKinX";
                }                
            } else
            if(FourPair(straightCard2, defaultCards)){
                if(IsPlayerCardIncluded(straightCard2,defaultCards)){
                       return "FourOfAKind"; 
                }else{
                    return "FourOfAKinX";
                }
            } else
            if(FourPair(straightCard1, defaultCards)){
                if(IsPlayerCardIncluded(straightCard1,defaultCards)){
                       return "FourOfAKind"; 
                }else{
                    return "FourOfAKinX";
                }
            } else
            if(FourPair(straightCard, defaultCards)){
                if(IsPlayerCardIncluded(straightCard,defaultCards)){
                       return "FourOfAKind"; 
                }else{
                    return "FourOfAKinX";
                }
            } else {
                return "Nope";
            }


    }

    private bool FourPair(List<Card> pc, List<Card> defaultCards){

            //Debug.Log("FourPair?");
            if(pc[0].value1 == pc[1].value1 && pc[1].value1 == pc[2].value1 && pc[2].value1 == pc[3].value1){
                return true;
            } else{
                return false;
            }

    }

    private string Flush(List<Card> pc, List<Card> defaultCards, string playerWho){

        int isClubs = 0;
        int isDiamonds = 0;
        int isHearts = 0;
        int isSpades = 0;    
        
        List<Card> ClubCards = new List<Card>();
        List<Card> DiamondCards = new List<Card>();
        List<Card> HeartsCards = new List<Card>();
        List<Card> SpadesCards = new List<Card>();

        foreach(Card p in pc){
           // Debug.Log(p.value1);
            if(p.name == "Clubs"){
                isClubs++;
                ClubCards.Add(p);
            } else if(p.name == "Diamonds"){
                isDiamonds++;
                DiamondCards.Add(p);
            }else if(p.name == "Hearts"){
                isHearts++;
                HeartsCards.Add(p);
            }else if(p.name == "Spades"){
                isSpades++;
                SpadesCards.Add(p);
            }else{

            }
        }
          
        if(isClubs > 4){
               
                if(IsPlayerCardIncluded(removeLastExcessCard(ClubCards), defaultCards)){
                        return "Flush";
                }else{
                        return "FlusX";
                }
            }else 
            if(isDiamonds > 4 ){
               // Debug.Log("Suite > 4");
                if(IsPlayerCardIncluded(removeLastExcessCard(DiamondCards), defaultCards)){
                        return "Flush";
                }else{
                        return "FlusX";
                }
            } else
            if(isHearts > 4 ){
               // Debug.Log("Suite > 4");
                if(IsPlayerCardIncluded(removeLastExcessCard(HeartsCards), defaultCards)){
                        return "Flush";
                }else{
                        return "FlusX";
                }
            }else
            if(isSpades > 4){
               // Debug.Log("Suite > 4");
                if(IsPlayerCardIncluded(removeLastExcessCard(SpadesCards), defaultCards)){
                        return "Flush";
                }else{
                        return "FlusX";
                }
            }else{
                return "Nope";
            }           
            return "Nope";
        
    }

    
    

    private string FullHouse(List<Card> pc, List<Card> defaultCards, string playerWho){

            //return "Nope";
       // Debug.Log("Checking Fullhouse");
        
        int countCards = 0;
        bool threePairFound = false;
        bool isCardThere = false;    
        foreach(Card p in pc){
            countCards++;            
        }
        pc.Sort();
        pc.Reverse();
        
        countCards--;
        bool found = true;

        List<Card> straightCard = new List<Card>();

            for (int i = 0; i < 5 ; i++){
                   if(pc[i].value1 == pc[i + 1].value1 && pc[i + 1].value1 == pc[i + 2].value1){
                      Debug.Log("FullHouse - 3 Match Found:" + pc[i].value1 + " & " + pc[i + 1].value1 + " & "+ pc[i+2].value1);
                            if(found){
                            threePairFound = true;                                                        
                            straightCard.Add(pc[i]);
                            straightCard.Add(pc[i+1]);
                            straightCard.Add(pc[i+2]);
                            found = false;
                            }
                   } else{
                       //Debug.Log("List:"+i +" : " + pc[i].value1 + " & " + pc[i + 1].value1 + " & "+ pc[i+2].value1);
                   }
            }    
            
        //Debug.Log("threePairFound: " + threePairFound);
        //Debug.Log("iValue "+ iValue);

    
          
        if(threePairFound){
            Debug.Log("3 pair found");
                //List<Card> minusCard = new List<Card>(MinusCards(straightCard,pc)) ;          
                List<Card> minusCard = new List<Card>(MinusCards(straightCard,pc)) ;                
                        if(FindLast2Pair(minusCard)){
                            Debug.Log("2 pair found");
                                if(IsPlayerCardIncluded(straightCard,defaultCards) || IsPlayerCardIncluded(minusCard,defaultCards)){
                                        return "FullHouse";
                                }else{return "FullHousX";}
                        }else{return "Nope";}
        } else {
                return "Nope";
        }

    }

    
    private List<Card> MinusCards(List<Card> toRemove, List<Card> removeFrom){
        Debug.Log("processing MinusCard");
        
        int toRemoveInt = 0;        
        foreach(Card p in toRemove){
                toRemoveInt++;
        }    
        Debug.Log("toRemoveInt:" + toRemoveInt);
        
        int removeFromInt=0;
        foreach(Card p in removeFrom){
            removeFromInt++;
        }
        Debug.Log("removeFromInt:" + removeFromInt);

            for(int i = 0; i < toRemoveInt; i++){
                for(int e = 0; e < removeFromInt ; e++){
                    if(toRemove[i].value1 == removeFrom[e].value1){
                        removeFrom.Remove(removeFrom[e]);
                        removeFromInt--;
                        Debug.Log("removeFromInt = "+ removeFromInt);
                    }
                }                
            }

            foreach(Card p in removeFrom){
                Debug.Log("removeFromCards : " + p.value1);                
            }

            return removeFrom;

    }






   
    private bool FindLast2Pair(List<Card> pc){

        int countCards = 0;
        foreach(Card p in pc){
            countCards++;
            //Debug.Log("StraightLastCards:"+countCards + " : " + p.value1 + p.name );
        }
        
        bool isPair = false;
        countCards--;

            for (int i = 0; i < countCards ; i++){
                   if(pc[i].value1 == pc[i + 1].value1){
                      // Debug.Log("Match Found:" + pc[i].value1 + " & " + pc[i + 1].value1);                       
                       isPair = true;                      
                   } else{
                       Debug.Log("No match");
                       
                   }
            }
        if(isPair){
            return true;
        }else{
            return false;
        }

    }


    private string Straight(List<Card> pc, List<Card> defaultCards, string playerWho){

            
        
    List<Card> straightCard = new List<Card>();
    List<Card> straightCard1 = new List<Card>();
    List<Card> straightCard2 = new List<Card>();
    

        pc.Sort();
        pc.Reverse();

            for(int i = 0; i < 5; i++){
                straightCard.Add(pc[i]);
            }

            for(int i = 1; i < 6; i++){
                straightCard1.Add(pc[i]);
            }
        
            for(int i = 2; i < 7; i++){
                straightCard2.Add(pc[i]);
            }
    
           if(checkIfStraight2(straightCard, defaultCards, playerWho)){
                if(IsPlayerCardIncluded(straightCard,defaultCards)){                    
                    return "Straight" ;
                } else { 
                    return "StraighX" ;
                    }
           }else
           if(checkIfStraight2(straightCard1, defaultCards, playerWho)){
                if(IsPlayerCardIncluded(straightCard1,defaultCards)){                    
                    return "Straight" ;
                } else { 
                    return "StraighX" ;
                    }
           }else
           if(checkIfStraight2(straightCard2, defaultCards, playerWho)){
                if(IsPlayerCardIncluded(straightCard2,defaultCards)){                    
                    return "Straight" ;
                } else { 
                    return "StraighX" ;
                    }
           }else{
               return "Nope";
           } 


    }

private bool checkIfStraight2(List<Card> straightCard, List<Card> defaultCards, string playerWho){

          //  Debug.Log("checkIfStraight");

        straightCard.Sort();

         if((straightCard[0].value1 + 1 == straightCard[1].value1) && (straightCard[1].value1 + 1 == straightCard[2].value1) 
        && (straightCard[2].value1 + 1 == straightCard[3].value1) && (straightCard[3].value1 + 1 == straightCard[4].value1)) {

                return true;
        } else{
                return false ;
        }

    }

    
    private string ThreeOfAKind(List<Card> pc, List<Card> defaultCards, string playerWho){
    
    //Debug.Log("Checking if ThreeOfAKind");
    
    List<Card> straightCard = new List<Card>();
    List<Card> straightCard1 = new List<Card>();
    List<Card> straightCard2 = new List<Card>();
    List<Card> straightCard3 = new List<Card>(); 
    List<Card> straightCard4 = new List<Card>();

        pc.Sort();
        
            for(int i = 0; i < 3; i++){
                straightCard.Add(pc[i]);
            }
            for(int i = 1; i < 4; i++){
                straightCard1.Add(pc[i]);
            }        
            for(int i = 2; i < 5; i++){
                straightCard2.Add(pc[i]);
            }
            for(int i = 3; i < 6; i++){
                straightCard3.Add(pc[i]);
            }
            for(int i = 4; i < 7; i++){
                straightCard4.Add(pc[i]);
            }

            if(ThreePairNoCheck(straightCard4, defaultCards, playerWho)){
                if(IsPlayerCardIncluded(straightCard4, defaultCards)){
                        return "ThreeOfAKind";
                }else{  return "ThreeOfAKinX"; }
                
            } else
            if(ThreePairNoCheck(straightCard3, defaultCards, playerWho)){
                if(IsPlayerCardIncluded(straightCard3, defaultCards)){
                        return "ThreeOfAKind";
                }else{  return "ThreeOfAKinX"; }
            } else
            if(ThreePairNoCheck(straightCard2, defaultCards, playerWho)){
                if(IsPlayerCardIncluded(straightCard2, defaultCards)){
                        return "ThreeOfAKind";
                }else{  return "ThreeOfAKinX"; }
            } else
            if(ThreePairNoCheck(straightCard1, defaultCards, playerWho)){
                if(IsPlayerCardIncluded(straightCard1, defaultCards)){
                        return "ThreeOfAKind";
                }else{  return "ThreeOfAKinX"; }
            }else    
            if(ThreePairNoCheck(straightCard, defaultCards, playerWho)){
                if(IsPlayerCardIncluded(straightCard4, defaultCards)){
                        return "ThreeOfAKind";
                }else{  return "ThreeOfAKinX"; }
            } else {            
                return "Nope";
            }
    }

    private bool ThreePairNoCheck(List<Card> pc, List<Card> defaultCards, string playerWho){

        //Debug.Log("ThreePair?");
            if(pc[0].value1 == pc[1].value1 && pc[1].value1 == pc[2].value1){
                
               return true;

            } else{
                return false;
            }


    } 

    private bool ThreePair(List<Card> pc, List<Card> defaultCards, string playerWho){

        //Debug.Log("ThreePair?");
            if(pc[0].value1 == pc[1].value1 && pc[1].value1 == pc[2].value1){
                
                if(IsPlayerCardIncluded(pc,defaultCards)){                    
                   // Debug.Log("ThreePair!!!");
                   MatchCardValueAndWho(pc[0].value1, playerWho);
                    return true ;
                }else{ 
                    return false; 
                    }

            } else{
                return false;
            }


    }   


    private string TwoPairs(List<Card> pc, List<Card> defaultCards, string playerWho){

        
        int countCards = 0;
        int twoPairFound = 0;
        bool isCardThere = false;
        foreach(Card p in pc){
            countCards++;
            //Debug.Log("StraightLastCards:"+countCards + " : " + p.value1 + p.name );
        }
        pc.Reverse();
        
        countCards--;

            for (int i = 0; i < countCards ; i++){
                   if(pc[i].value1 == pc[i + 1].value1){
                      // Debug.Log("Match Found:" + pc[i].value1 + " & " + pc[i + 1].value1);
                            twoPairFound++;
                            if(defaultCards[0].value1 == pc[i].value1){ 
                                isCardThere = true;
                                MatchCardValueAndWho(pc[i].value1, playerWho); 
                            }
                            if(defaultCards[1].value1 == pc[i].value1){ 
                                isCardThere = true;
                                MatchCardValueAndWho(pc[i].value1, playerWho); 
                                }                  
                   } else{
                       
                   }
            }    
            
        //Debug.Log("twoPairFound: " + twoPairFound);

        if(twoPairFound > 1 && isCardThere ){
                return "TwoPairs";
        } else {
                return "Nope";
        }



    }

    private string OnePair(List<Card> pc, List<Card> defaultCards, string playerWho){

        bool card1 = false;
        bool card2 = false;

        foreach(Card p in publiccard){
               if(p.value1 == defaultCards[0].value1){ card1 = true; MatchCardValueAndWho(p.value1, playerWho);}
               if(p.value1 == defaultCards[1].value1){ card2 = true; MatchCardValueAndWho(p.value1, playerWho);} 
        }

        if(card1 || card2){
            return "OnePair";
        }else if(defaultCards[0].value1 == defaultCards[1].value1) 
            return "OnePair";
        else{
            return "Nope";
        }

    }

    private void MatchCardValueAndWho(int num, string playerWho){

            if(playerWho == "player1"){
                MatchCardValueAndWho1 = num;
                MatchValueWho1.text = num.ToString();
            }else{
                MatchCardValueAndWho2 = num;
                MatchValueWho2.text = num.ToString();
            }

    }


    private int HighCard(List<Card> pc, string playerWho){

        Debug.Log(pc[0].value1 + " : " + pc[1].value1);

         if(pc[0].value1 > pc[1].value1){
           //  MatchCardValueAndWho(pc[0].value1,playerWho);
             return pc[0].value1;
         }else{
           //  MatchCardValueAndWho(pc[1].value1,playerWho);
             return pc[1].value1;
         }

    }

    private int LowCard(List<Card> pc, string playerWho){

         if(pc[0].value1 < pc[1].value1){
           //  MatchCardValueAndWho(pc[1].value1,playerWho);
             return pc[1].value1;
         }else{
           //  MatchCardValueAndWho(pc[0].value1,playerWho);
             return pc[0].value1;
         }

    }
   




    public void PlayAgain(){

            player1card.Clear();
            player2card.Clear();
            publiccard.Clear();
            playerClubs.Clear();
            playerDiamonds.Clear();
            playerHearts.Clear();
            playerSpades.Clear();
            player1publiccard.Clear();
            player2publiccard.Clear();
            gameResult.text = "";
            MatchValueWho1.text = "";
            MatchValueWho2.text = "";
            if(cardCount < 20){
            
            ButtonText.text = "Play Last Set";

            }


        if(cardCount < 9){            
            
            
            SceneManager.LoadScene("Poker");
            
        } else
        {
             StartCoroutine(SetCard(card));
        }

    }


}
