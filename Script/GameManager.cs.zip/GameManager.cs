﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{

    public Texture[] CardTexture;
    public Sprite[] CardSprite;

    public Image player1card1Image;
    public Image player1card2Image;
    public Image player2card1Image;
    public Image player2card2Image;

    public Image publiccard1Image;
    public Image publiccard2Image;
    public Image publiccard3Image;
    public Image publiccard4Image;
    public Image publiccard5Image;

    public List<Card> card = new List<Card>(); 

    public List<Card> player1card1 = new List<Card>(); 
    public List<Card> player1card2 = new List<Card>(); 
    public List<Card> player2card1 = new List<Card>(); 
    public List<Card> player2card2 = new List<Card>(); 

    public List<Card> publiccard1 = new List<Card>(); 
    public List<Card> publiccard2 = new List<Card>();
    public List<Card> publiccard3 = new List<Card>();
    public List<Card> publiccard4 = new List<Card>();
    public List<Card> publiccard5 = new List<Card>();

    public Text ButtonText;
    

    public int cardCount ;

    // Start is called before the first frame update
    void Start()
    {
        int num = 0;

        string type = "Clubs";   
        card.Add(new Card("2 of "+type, 2 , 2, CardSprite[num++]));
        card.Add(new Card("3 of "+type, 3 , 3, CardSprite[num++]));
        card.Add(new Card("4 of "+type, 4 , 4, CardSprite[num++]));
        card.Add(new Card("5 of "+type, 5 , 5, CardSprite[num++]));
        card.Add(new Card("6 of "+type, 6 , 6, CardSprite[num++]));
        card.Add(new Card("7 of "+type, 7 , 7, CardSprite[num++]));
        card.Add(new Card("8 of "+type, 8 , 8, CardSprite[num++]));
        card.Add(new Card("9 of "+type, 9 , 9, CardSprite[num++])); 
        card.Add(new Card("10 of "+type, 10 , 10, CardSprite[num++]));
        card.Add(new Card("Jack of "+type, 11 , 11, CardSprite[num++]));
        card.Add(new Card("Queen of "+type, 12 , 12, CardSprite[num++]));
        card.Add(new Card("King of "+type, 13 , 13, CardSprite[num++]));               
        card.Add(new Card("Ace of "+type, 14 , 1, CardSprite[num++]));
        
        type = "Dianmonds";
        card.Add(new Card("2 of "+type, 2 , 2, CardSprite[num++]));
        card.Add(new Card("3 of "+type, 3 , 3, CardSprite[num++]));
        card.Add(new Card("4 of "+type, 4 , 4, CardSprite[num++]));
        card.Add(new Card("5 of "+type, 5 , 5, CardSprite[num++]));
        card.Add(new Card("6 of "+type, 6 , 6, CardSprite[num++]));
        card.Add(new Card("7 of "+type, 7 , 7, CardSprite[num++]));
        card.Add(new Card("8 of "+type, 8 , 8, CardSprite[num++]));
        card.Add(new Card("9 of "+type, 9 , 9, CardSprite[num++])); 
        card.Add(new Card("10 of "+type, 10 , 10, CardSprite[num++]));
        card.Add(new Card("Jack of "+type, 11 , 11, CardSprite[num++]));
        card.Add(new Card("Queen of "+type, 12 , 12, CardSprite[num++]));
        card.Add(new Card("King of "+type, 13 , 13, CardSprite[num++]));               
        card.Add(new Card("Ace of "+type, 14 , 1, CardSprite[num++]));

        type = "Hearts";
         card.Add(new Card("2 of "+type, 2 , 2, CardSprite[num++]));
        card.Add(new Card("3 of "+type, 3 , 3, CardSprite[num++]));
        card.Add(new Card("4 of "+type, 4 , 4, CardSprite[num++]));
        card.Add(new Card("5 of "+type, 5 , 5, CardSprite[num++]));
        card.Add(new Card("6 of "+type, 6 , 6, CardSprite[num++]));
        card.Add(new Card("7 of "+type, 7 , 7, CardSprite[num++]));
        card.Add(new Card("8 of "+type, 8 , 8, CardSprite[num++]));
        card.Add(new Card("9 of "+type, 9 , 9, CardSprite[num++])); 
        card.Add(new Card("10 of "+type, 10 , 10, CardSprite[num++]));
        card.Add(new Card("Jack of "+type, 11 , 11, CardSprite[num++]));
        card.Add(new Card("Queen of "+type, 12 , 12, CardSprite[num++]));
        card.Add(new Card("King of "+type, 13 , 13, CardSprite[num++]));               
        card.Add(new Card("Ace of "+type, 14 , 1, CardSprite[num++]));

        type = "Spades";
        card.Add(new Card("2 of "+type, 2 , 2, CardSprite[num++]));
        card.Add(new Card("3 of "+type, 3 , 3, CardSprite[num++]));
        card.Add(new Card("4 of "+type, 4 , 4, CardSprite[num++]));
        card.Add(new Card("5 of "+type, 5 , 5, CardSprite[num++]));
        card.Add(new Card("6 of "+type, 6 , 6, CardSprite[num++]));
        card.Add(new Card("7 of "+type, 7 , 7, CardSprite[num++]));
        card.Add(new Card("8 of "+type, 8 , 8, CardSprite[num++]));
        card.Add(new Card("9 of "+type, 9 , 9, CardSprite[num++])); 
        card.Add(new Card("10 of "+type, 10 , 10, CardSprite[num++]));
        card.Add(new Card("Jack of "+type, 11 , 11, CardSprite[num++]));
        card.Add(new Card("Queen of "+type, 12 , 12, CardSprite[num++]));
        card.Add(new Card("King of "+type, 13 , 13, CardSprite[num++]));               
        card.Add(new Card("Ace of "+type, 14 , 1, CardSprite[num++]));
    

        card.Sort();
        
        
        foreach (Card cardResult in card)
        {
           // Debug.Log( cardResult.name + cardResult.value1 + cardResult.value2);
            cardCount++;
        }

        StartCoroutine(SetCard(card));
    }

    public IEnumerator SetCard(List<Card> card){
        
        //Debug.Log("SetCard Function");
        float timer = 0.1f;
        SetPlayerCard(card , player1card1, player1card1Image);
        yield return new WaitForSeconds(timer);
        SetPlayerCard(card , player1card2, player1card2Image);
        yield return new WaitForSeconds(timer);
        SetPlayerCard(card , player2card1, player2card1Image);
        yield return new WaitForSeconds(timer);
        SetPlayerCard(card , player2card2, player2card2Image);
        yield return new WaitForSeconds(timer);
        SetPlayerCard(card , publiccard1, publiccard1Image);
        yield return new WaitForSeconds(timer);
        SetPlayerCard(card , publiccard2, publiccard2Image);
        yield return new WaitForSeconds(timer);
        SetPlayerCard(card , publiccard3, publiccard3Image);
        yield return new WaitForSeconds(timer);
        SetPlayerCard(card , publiccard4, publiccard4Image);
        yield return new WaitForSeconds(timer);
        SetPlayerCard(card , publiccard5, publiccard5Image);
        yield return new WaitForSeconds(timer);

        CheckCards();        
    }


    void SetPlayerCard(List<Card> card, List<Card> playercard, Image cardImage){
       int i = Random.Range(0,cardCount);
       //Debug.Log(cardCount);
       // Debug.Log(card[i].name + card[i].value1);  
        playercard.Add(new Card(card[i].name ,card[i].value1  , card[i].value2, card[i].sprite ));
        cardImage.GetComponent<Image>().sprite = card[i].sprite;
       // string cardSpriteName = CardSprite[i].ToString();
        card.Remove(card[i]);
        cardCount = cardCount - 1;
        //Debug.Log("cardCount:"+cardCount);
        
    }

    void CheckCards(){


        Debug.Log("player1card1: " + player1card1[0].name);
        Debug.Log("player1card2: " + player1card2[0].name);
        Debug.Log("player2card1: " + player2card1[0].name);
        Debug.Log("player2card1: " + player2card2[0].name);

        Debug.Log("publiccard1: " + publiccard1[0].name);
        Debug.Log("publiccard2: " + publiccard2[0].name);
        Debug.Log("publiccard3: " + publiccard3[0].name);
        Debug.Log("publiccard4: " + publiccard4[0].name);
        Debug.Log("publiccard5: " + publiccard5[0].name);



        Debug.Log("cardCount:"+cardCount);



        

        foreach (Card cardResult in card)
        {
        //   Debug.Log( cardResult.name + cardResult.value1 + cardResult.value2);
            //cardCount++;
        }


    }


    public void PlayAgain(){

       
            if(cardCount < 20){
            
            ButtonText.text = "Last Game";

            }


        if(cardCount < 9){            
            
            
            SceneManager.LoadScene("Poker");
            
        } else
        {
             StartCoroutine(SetCard(card));
        }

    }


}
